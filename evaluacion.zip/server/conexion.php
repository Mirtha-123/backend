<?php

  class ConectorDB
  {
      private $host;
      private $user;
      private $pass;
      private $conexion;

    function __construct($host, $user, $pass){
      $this->host = $host;
      $this->user = $user;
      $this->pass = $pass;
    }


    function iniciarConexion($nombre_db)
    {
      $this->conexion = new mysqli($this->host,$this->user,$this->pass,$nombre_db);
      if ($this->conexion->connect_error) {
        return "Error:". $this->conexion->connect_error;
      }else {
        return "OK";
      }
    }

    function ejecutarConsulta($query){
      return $this->conexion->query($query);
    }

    function cerrarConexion(){
      $this->conexion->close();
    }

    function insertarDatos ($tabla,$datos){
      $sql = 'INSERT INTO '.$tabla.' (';
      $i = 1;
      foreach ($datos as $key => $value) {
        $sql .= $key;
        if ($i<count($datos)) {
          $sql .= ', ';
        }else {
          $sql .= ')';
        }
        $i++;
      }
      $sql .= ' VALUES (';
      $i =1;
      foreach ($datos as $key => $value) {
        $sql .= $value;
        if ($i<count($datos)) {
          $sql.=', ';
        }else {
          $sql.=');';
        }
        $i++;
      }

      return $this->ejecutarConsulta($sql);
    }
      function getConexion(){
        return $this->conexion;
      }

      function actualizarDato($tabla, $datos, $condicion){
        $sql = 'UPDATE '.$tabla.' SET ';
        $i =1;
        foreach ($datos as $key => $value) {
          $sql .= $key.'='.$value;
          if ($i<sizeof($datos)) {
            $sql .= ', ';
          }else {
            $sql .= ' WHERE '.$condicion.';';
          }
          $i++;
                }

          return $this->ejecutarConsulta($sql);
      }

      function eliminarDato($tabla, $condicion){
        $sql = 'DELETE FROM '.$tabla.' WHERE '.$condicion.";";
        return $this->ejecutarConsulta($sql);
      }
      function consultar($tablas, $campos, $condicion = ""){
        $sql = "SELECT ";
        $ultima_key = end(array_keys($campos));
        foreach ($campos as $key => $value) {
          $sql .= $value;
          if ($key!=$ultima_key) {
            $sql.=", ";
          }else {
            $sql .= " FROM ";
          }
        }

        $ultima_key = end(array_keys($tablas));
        foreach ($tablas as $key => $value) {
          $sql .=$value;
          if ($key!=$ultima_key) {
            $sql.=", ";

          }else {
            $sql.=" ";
          }
        }
        if ($condicion=="") {
          $sql .=";";
        }else {
          $sql .= $condicion.";";
        }

        return $this->ejecutarConsulta($sql);
      }

      
  }


 ?>
