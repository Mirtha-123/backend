<?php

    require ('./conexion.php');

      $con = new ConectorDB('localhost','pedro','pedro123');

      $response['conexion']= $con->iniciarConexion('full_calendar');

      if ($response['conexion']=='OK') {
          $resultado_consulta = $con->consultar(['usuarios'],['correo', 'contrasena'], 'WHERE correo="'.$_POST['username'].'"');
          $fila = $resultado_consulta->fetch_assoc();
          $comprobante = password_hash($fila['contrasena'],PASSWORD_DEFAULT);
          if ($resultado_consulta->num_rows != 0) {

            if (password_verify($_POST['password'], $comprobante)) {
              $response['msg'] = 'OK';
              session_start();
              $_SESSION['username']= $fila['correo'];
            }else{
              $response['msg']= 'Contraseña Incorrecta';

            }
          }else {
              $response['msg'] = 'Username Incorrecto';

          }

      }

      echo json_encode($response);

      $con->cerrarConexion();


 ?>
