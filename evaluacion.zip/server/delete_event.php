<?php
include('conexion.php');

  $data = "'".$_POST['id']."'";


  $con = new ConectorDB('localhost','pedro','pedro123');
  $response['conexion']= $con->iniciarConexion('full_calendar');

    if ($response['conexion']=='OK') {
      if ($con->eliminarDato('eventos', 'title ='.$data.';')) {
        $response['msg']= "OK";
      }else {
        $response['msg']="Hubo un error y los datos no han sido eliminados";
      }
    }else {
      $response['msg']= "No se pudo conectar a la base de datos";
    }
  echo json_encode($response);
  $con->cerrarConexion();


 ?>
