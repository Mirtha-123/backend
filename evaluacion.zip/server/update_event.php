<?php
include('conexion.php');
session_start();


  $data['title'] = "'".$_POST['id']."'";
  $data['empieza'] = "'".$_POST['start_date']." ".$_POST['start_hour']."'";
  $data['termina'] = "'".$_POST['end_date']." ".$_POST['end_hour']."'";



  $con = new ConectorDB('localhost','pedro','pedro123');
  $response['conexion']= $con->iniciarConexion('full_calendar');
  if ($response['conexion']=='OK') {
    if ($con->actualizarDato('eventos', $data, 'title = '.$data['title'])) {
      $response['msg']= "exito en la actualizacion";
    }else {
      $response['msg']="Hubo un error y los datos no han sido cargado";
    }
  }else {
    $response['msg']= "No se pudo conectar a la base de datos";
  }
  echo json_encode($response);
  $con->cerrarConexion();




 ?>
