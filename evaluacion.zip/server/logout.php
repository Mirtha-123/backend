<?php
if(isset($_SESSION['username']))
{
     echo "No hay ninguna sesion iniciada";
//esto ocurre cuando la sesion caduca.

}
else
{
  session_destroy();
  header('Location: ../client/index.html');
    //echo "Has cerrado la sesion";
echo "<meta content='0;URL=index.php?content=Formularioresgistro.php' http-equiv='REFRESH'> </meta>";

}

 ?>
