<?php
    include('conexion.php');
    session_start();


      $data['title'] = "'".$_POST['titulo']."'";
      $data['empieza'] = "'".$_POST['start_date']."'";
      $data['termina'] = "'".$_POST['end_date']."'";
      $data['url'] = "'null'";
      $data['className'] = "'Disponible'";
      $data['prendido'] = "'1'";


      $con = new ConectorDB('localhost','pedro','pedro123');
      $response['conexion']= $con->iniciarConexion('full_calendar');
      $resultado = $con->consultar(['usuarios'], ['id_usuario'], "WHERE correo ='".$_SESSION['username']."'");
      $fila = $resultado->fetch_assoc();

     $data['pertenece'] = $fila['id_usuario'];
      if ($response['conexion']=='OK') {
        if ($con->insertarDatos('eventos', $data)) {
          $response['msg']= "exito en la insercion";
        }else {
          $response['msg']="Hubo un error y los datos no han sido cargado";
        }
      }else {
        $response['msg']= "No se pudo conectar a la base de datos";
      }
      echo json_encode($response);
      $con->cerrarConexion();


 ?>
