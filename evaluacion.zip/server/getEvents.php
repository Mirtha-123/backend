<?php
      require('conexion.php');

      session_start();

      if (isset($_SESSION['username'])) {

      $con = new ConectorDB('localhost','pedro','pedro123');
      if ($con->iniciarConexion('full_calendar')=='OK') {
        $resultado = $con->consultar(['usuarios'], ['id_usuario'], "WHERE correo ='".$_SESSION['username']."'");
        $fila = $resultado->fetch_assoc();
        $respon['nombre']=$fila['id_usuario'];

        $resultado = $con->consultar(['eventos'], ['title','empieza','termina','url','className','prendido'], "WHERE pertenece ='".$respon['nombre']."'");
        $i=0;


      while ($fila = $resultado->fetch_assoc()) {
          $response['eventos'][$i]['id']=$fila['title'];
          $response['eventos'][$i]['title']=$fila['title'];
          $response['eventos'][$i]['start']=$fila['empieza'];
          $response['eventos'][$i]['end']=$fila['termina'];
          $response['eventos'][$i]['url']=$fila['url'];
          $response['eventos'][$i]['className']=$fila['className'];
          $response['eventos'][$i]['editable']=$fila['prendido'];
          $i++;
        }
        $response['msg'] = "OK";

      }else {
        $response['msg'] = "No se pudo conectar a la Base de Datos";
      }
      }else {
      $response['msg'] = "No se ha iniciado una sesión";
      }

      echo json_encode($response);
      $con->cerrarConexion();




 ?>
