-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-11-2017 a las 02:42:18
-- Versión del servidor: 10.1.21-MariaDB
-- Versión de PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `full_calendar`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `eventos`
--

CREATE TABLE `eventos` (
  `id_evento` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `empieza` datetime DEFAULT NULL,
  `termina` datetime DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `className` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `prendido` tinyint(1) DEFAULT NULL,
  `pertenece` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `eventos`
--

INSERT INTO `eventos` (`id_evento`, `title`, `empieza`, `termina`, `url`, `className`, `prendido`, `pertenece`) VALUES
(1, 'Primer Evento', '2017-10-05 00:00:00', '2017-10-08 00:00:00', NULL, 'Disponible', 1, 1),
(2, 'Segundo Evento', '2017-10-01 00:00:00', '2017-10-08 00:00:00', NULL, 'Disponible', 1, 1),
(3, 'Primer Evento', '2017-10-10 00:00:00', '2017-10-12 00:00:00', NULL, 'Disponible', 1, 1),
(4, 'Fiesta', '2017-11-06 00:00:00', '2017-11-09 00:00:00', '', 'Disponible', 0, 1),
(5, 'REUNION DE PADRES', '2017-11-01 00:00:00', '2017-11-02 00:00:00', NULL, 'Disponible', 1, 1),
(6, 'nuevo viaje', '2017-11-21 00:00:00', '2017-11-28 00:00:00', NULL, 'Disponible', 1, 1),
(7, 'Viaje', '2017-11-25 00:00:00', '2017-11-27 00:00:00', 'null', 'Disponible', 1, 1),
(8, 'partido de futbol', '2017-11-25 00:00:00', '2017-11-27 00:00:00', 'null', 'Disponible', 1, 1),
(9, 'tomar te', '2017-11-07 00:00:00', '2017-11-27 00:00:00', 'null', 'Disponible', 1, 1),
(10, 'cumple', '2017-11-01 00:00:00', '2017-09-10 00:00:00', 'null', 'Disponible', 1, 1),
(11, 'reunion sabatica', '2017-10-01 06:00:00', '2017-10-01 05:00:00', 'null', 'Disponible', 1, 1),
(12, 'hola', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'null', 'Disponible', 1, 1),
(13, 'hola', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'null', 'Disponible', 1, 1),
(14, 'fiesta', '2017-11-03 05:00:00', '2017-11-03 19:30:00', 'null', 'Disponible', 1, 1),
(15, 'ensenada', '2017-11-12 07:00:00', '2017-11-15 22:30:00', 'null', 'Disponible', 1, 1),
(16, 'parrillada', '2017-12-21 06:00:00', '2017-12-23 09:30:00', 'null', 'Disponible', 1, 1),
(18, 'comer', '2017-11-02 00:00:00', '2017-11-11 00:00:00', 'null', 'Disponible', 1, 1),
(19, 'comer', '2017-12-06 00:00:00', '2017-12-06 00:00:00', 'null', 'Disponible', 1, 1),
(20, 'festejar', '2017-12-01 00:00:00', '0000-00-00 00:00:00', 'null', 'Disponible', 1, 1),
(21, 'ppp', '2017-12-02 00:00:00', '2017-12-02 00:00:00', 'null', 'Disponible', 1, 1),
(22, 'aaa', '2017-12-03 00:00:00', '2017-12-03 00:00:00', 'null', 'Disponible', 1, 1),
(23, 'fiesta', '2017-11-04 00:00:00', '2017-11-04 00:00:00', 'null', 'Disponible', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `nombre` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `apellido` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `correo` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `contrasena` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nombre`, `apellido`, `fecha_nacimiento`, `correo`, `contrasena`) VALUES
(1, 'Pedro', 'Rivera', '1995-05-15', 'riverv83500@gmail.com', 'pedro123'),
(2, 'Mirtha', 'Flores', '1997-01-23', 'flores_ali@gmail.com', 'flores123'),
(3, 'Sebastian', 'Rivera', '1995-05-13', 'river@gmail.com', NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `eventos`
--
ALTER TABLE `eventos`
  ADD PRIMARY KEY (`id_evento`),
  ADD KEY `pertenece` (`pertenece`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `eventos`
--
ALTER TABLE `eventos`
  MODIFY `id_evento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `eventos`
--
ALTER TABLE `eventos`
  ADD CONSTRAINT `pertenece` FOREIGN KEY (`pertenece`) REFERENCES `usuarios` (`id_usuario`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
